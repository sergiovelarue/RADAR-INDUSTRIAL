# Simulador de Ventas — Radar Industrial
Datos 100% simulados (aleatorios pero coherentes con el historial real de cada cliente), solo para pruebas de la función "Actualización diaria".

## Cómo usar cada archivo
En la pestaña "Actualización diaria" (solo Administrador), sube:
- El archivo que dice **Ventas_Espumas** en el campo "Ventas Espumas 2026"
- El archivo que dice **Ventas_Colchones** en el campo correspondiente (va en cero, ya que hoy todo el negocio es Espumas — lo incluyo solo porque el formulario pide ambos)

## Calendario sugerido (un archivo cada lunes)

| Semana | Lunes sugerido | Mes simulado | Momento del mes |
|---|---|---|---|
| 1 | 27/07/2026 | Junio | Semana 1 (18% del mes) |
| 2 | 03/08/2026 | Junio | Semana 2 (42% del mes) |
| 3 | 10/08/2026 | Junio | Semana 3 (72% del mes) |
| 4 | 17/08/2026 | Junio | Cierre de mes (100%) |
| 5 | 24/08/2026 | Julio | Semana 1 |
| 6 | 31/08/2026 | Julio | Semana 2 |
| 7 | 07/09/2026 | Julio | Semana 3 |
| 8 | 14/09/2026 | Julio | Cierre de mes |
| 9 | 21/09/2026 | Agosto | Semana 1 |
| 10 | 28/09/2026 | Agosto | Semana 2 |
| 11 | 05/10/2026 | Agosto | Semana 3 |
| 12 | 12/10/2026 | Agosto | Cierre de mes |

Cada archivo semanal reemplaza al anterior (no se suman): cada uno trae el año completo Enero-Diciembre, con los meses ya cerrados en su valor final, el mes en curso creciendo semana a semana, y los meses futuros en cero — igual que llegaría un reporte real de ventas acumuladas.

Los archivos "Cierre_[Mes]_..." son el mismo contenido que la Semana 4 de cada mes, con nombre más simple si solo quieres probar el consolidado mensual sin pasar por las semanas.

## Importante
- Esto es un simulador para pruebas — no son ventas reales.
- No tengo forma de enviarte esto por correo automáticamente cada lunes (no cuento con tareas programadas). Pídeme el siguiente archivo cuando lo necesites, o usa ya mismo los 12 que te dejo aquí.
